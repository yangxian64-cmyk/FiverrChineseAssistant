package com.fiverr.chineseassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MVP implementation: only handles Fiverr (com.fiverr.fiverr).
 * The service never writes text back into Fiverr. It creates a non-touchable
 * accessibility overlay so Fiverr remains clickable underneath.
 */
public class FiverrTranslationService extends AccessibilityService {
    private static final String FIVERR_PACKAGE = "com.fiverr.fiverr";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Map<String, String> cache = new HashMap<>();
    private final Set<String> inFlight = new HashSet<>();

    private WindowManager wm;
    private FrameLayout overlay;
    private Translator translator;
    private Runnable refreshRunnable;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                    | AccessibilityEvent.TYPE_VIEW_SCROLLED;
            info.packageNames = new String[]{FIVERR_PACKAGE};
            info.notificationTimeout = 150;
            setServiceInfo(info);
        }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        translator = Translation.getClient(new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.CHINESE)
                .build());

        // Download the English -> Chinese model. Translation stays on-device after this.
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().requireWifi().build())
                .addOnFailureListener(e -> { /* The overlay simply waits until the model is available. */ });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!FIVERR_PACKAGE.equals(event.getPackageName() == null ? null : event.getPackageName().toString())) return;
        if (refreshRunnable != null) mainHandler.removeCallbacks(refreshRunnable);
        refreshRunnable = () -> refreshOverlay();
        mainHandler.postDelayed(refreshRunnable, 220);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (refreshRunnable != null) mainHandler.removeCallbacks(refreshRunnable);
        removeOverlay();
        if (translator != null) translator.close();
        executor.shutdownNow();
        super.onDestroy();
    }

    private void refreshOverlay() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            removeOverlay();
            return;
        }
        ensureOverlay();
        overlay.removeAllViews();

        List<NodeText> nodes = new ArrayList<>();
        collectTextNodes(root, nodes);
        nodes = removeDuplicatesAndParents(nodes);

        for (NodeText n : nodes) {
            String cached = cache.get(n.text);
            if (cached != null) {
                addLabel(n.bounds, cached);
            } else {
                requestTranslation(n.text, n.bounds);
            }
        }
        root.recycle();
    }

    private void collectTextNodes(AccessibilityNodeInfo node, List<NodeText> out) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence cs = node.getText();
        if (cs != null) {
            String text = cs.toString().trim();
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            if (isTranslatable(text, r)) out.add(new NodeText(text, r));
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectTextNodes(child, out);
                child.recycle();
            }
        }
    }

    private boolean isTranslatable(String text, Rect r) {
        if (text.length() < 2 || text.length() > 160) return false;
        if (r.width() <= 0 || r.height() <= 0) return false;
        if (containsChinese(text)) return false;
        int letters = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) letters++;
        }
        return letters >= 2;
    }

    private boolean containsChinese(String s) {
        for (int i = 0; i < s.length(); i++) {
            Character.UnicodeBlock b = Character.UnicodeBlock.of(s.charAt(i));
            if (b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                    || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                    || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B) return true;
        }
        return false;
    }

    private List<NodeText> removeDuplicatesAndParents(List<NodeText> input) {
        List<NodeText> result = new ArrayList<>();
        for (NodeText a : input) {
            boolean overlappedDuplicate = false;
            for (NodeText b : result) {
                if (a.text.equals(b.text) || containsRect(b.bounds, a.bounds) || containsRect(a.bounds, b.bounds)) {
                    // Prefer the smaller visible text box to avoid double overlays from parent containers.
                    int aa = a.bounds.width() * a.bounds.height();
                    int bb = b.bounds.width() * b.bounds.height();
                    if (aa >= bb) overlappedDuplicate = true;
                    else result.remove(b);
                    break;
                }
            }
            if (!overlappedDuplicate) result.add(a);
        }
        return result;
    }

    private boolean containsRect(Rect outer, Rect inner) {
        return outer.left <= inner.left && outer.top <= inner.top
                && outer.right >= inner.right && outer.bottom >= inner.bottom;
    }

    private void requestTranslation(final String text, final Rect bounds) {
        synchronized (inFlight) {
            if (inFlight.contains(text)) return;
            inFlight.add(text);
        }
        executor.execute(() -> {
            try {
                String translated = Tasks.await(translator.translate(text));
                if (translated != null && !translated.trim().isEmpty()) {
                    cache.put(text, translated.trim());
                    mainHandler.post(this::refreshOverlay);
                }
            } catch (Exception ignored) {
            } finally {
                synchronized (inFlight) { inFlight.remove(text); }
            }
        });
    }

    private void ensureOverlay() {
        if (overlay != null) return;
        overlay = new FrameLayout(this);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        wm.addView(overlay, p);
    }

    private void addLabel(Rect r, String translated) {
        if (overlay == null) return;
        TextView tv = new TextView(this);
        tv.setText(translated);
        tv.setTextColor(Color.rgb(20,20,20));
        tv.setTextSize(13);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(5), 0, dp(5), 0);
        tv.setBackgroundColor(Color.argb(235, 255,255,255));
        tv.setSingleLine(false);
        tv.setMaxLines(4);
        tv.setElevation(dp(2));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(dp(30), r.width()), Math.max(dp(22), r.height()));
        lp.leftMargin = r.left;
        lp.topMargin = r.top;
        overlay.addView(tv, lp);
    }

    private void removeOverlay() {
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
            overlay = null;
        }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static class NodeText {
        final String text; final Rect bounds;
        NodeText(String text, Rect bounds) { this.text = text; this.bounds = bounds; }
    }
}
