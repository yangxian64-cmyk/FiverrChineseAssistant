# MVP: shrinking disabled.
