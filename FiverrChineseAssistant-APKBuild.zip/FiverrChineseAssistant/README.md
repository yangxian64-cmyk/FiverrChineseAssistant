# Fiverr 中文助手（Android MVP）

这是一个 Android 辅助应用：检测当前前台是否为 Fiverr（`com.fiverr.fiverr`），通过 AccessibilityService 读取 Fiverr 页面中的可访问文字，并用 TYPE_ACCESSIBILITY_OVERLAY 在原位置覆盖中文翻译。

## 已实现
- 只处理 Fiverr，不读取其它 App。
- 中英翻译使用 Google ML Kit on-device Translation。
- 首次使用需要下载 English -> Chinese 翻译模型；下载后翻译在设备本地完成。
- 覆盖层不可点击，因此 Fiverr 原来的按钮、输入框仍由你操作。
- 不修改 Fiverr 官方 APK，也不修改账号、订单或支付数据。

## 当前版本限制
- 对“可访问性树中有文字”的控件效果最好。
- 如果 Fiverr 把英文直接画在图片、Canvas 或某些特殊 WebView 表面，第一版可能无法识别；后续可以加入截图 OCR + 坐标覆盖，覆盖率会明显提高。
- 当前默认用白底中文覆盖原文，深色模式适配还比较粗糙。

## 构建
使用 Android Studio 直接打开项目目录。
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- compileSdk 35
- minSdk 23

首次同步会从 Google Maven 下载 ML Kit 依赖。

## 手机使用
1. 安装 APK。
2. 打开“Fiverr 中文助手”。
3. 点“开启中文翻译权限”。
4. 在系统无障碍设置中开启“Fiverr 中文助手”。
5. 回到应用并点“打开 Fiverr”。
6. 首次运行会下载英文→中文模型。

Google ML Kit translation is subject to Google's usage/attribution guidelines.
