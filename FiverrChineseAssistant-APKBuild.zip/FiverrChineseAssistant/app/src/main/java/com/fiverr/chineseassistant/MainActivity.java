package com.fiverr.chineseassistant;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.accessibilityservice.AccessibilityService;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null) status.setText(isServiceEnabled() ? "状态：已开启 ✓" : "状态：未开启");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(246,247,249));

        TextView title = new TextView(this);
        title.setText("Fiverr 中文助手");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(17,24,39));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, lp(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("打开 Fiverr 后，把页面里的英文自动覆盖成中文。\n第一版优先翻译可被 Android 读取的文字。");
        sub.setTextSize(16);
        sub.setTextColor(Color.rgb(75,85,99));
        sub.setPadding(0, dp(10), 0, dp(18));
        root.addView(sub, lp(-1, -2));

        status = new TextView(this);
        status.setTextSize(17);
        status.setTextColor(Color.rgb(37,99,235));
        status.setText(isServiceEnabled() ? "状态：已开启 ✓" : "状态：未开启");
        root.addView(status, lp(-1, -2));

        Button enable = new Button(this);
        enable.setText("① 开启中文翻译权限");
        enable.setTextSize(16);
        enable.setTextColor(Color.WHITE);
        enable.setAllCaps(false);
        enable.setBackgroundResource(com.fiverr.chineseassistant.R.drawable.button_bg);
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        LinearLayout.LayoutParams ep = lp(-1, dp(52));
        ep.topMargin = dp(22);
        root.addView(enable, ep);

        Button open = new Button(this);
        open.setText("② 打开 Fiverr");
        open.setTextSize(16);
        open.setAllCaps(false);
        open.setOnClickListener(v -> launchFiverr());
        LinearLayout.LayoutParams op = lp(-1, dp(52));
        op.topMargin = dp(12);
        root.addView(open, op);

        TextView note = new TextView(this);
        note.setText("使用方法：\n1. 点击“开启中文翻译权限”。\n2. 在系统无障碍设置中开启“Fiverr 中文助手”。\n3. 返回本应用，点击“打开 Fiverr”。\n4. 首次使用会下载英文→中文离线翻译模型。\n\n说明：这是屏幕覆盖翻译，不会修改 Fiverr 官方语言设置。Fiverr 官方移动端目前提供多种语言，但不包含中文。");
        note.setTextSize(14);
        note.setTextColor(Color.rgb(75,85,99));
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note, lp(-1, -2));

        setContentView(root);
    }

    private void launchFiverr() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.fiverr.fiverr");
        if (launch == null) {
            status.setText("没有找到 Fiverr，请先安装 Fiverr 官方应用。");
            return;
        }
        startActivity(launch);
    }

    private boolean isServiceEnabled() {
        android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        for (AccessibilityServiceInfo info : am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)) {
            ServiceInfoCompatHolder holder = new ServiceInfoCompatHolder(info);
            if (holder.matches(getPackageName(), FiverrTranslationService.class.getName())) return true;
        }
        return false;
    }

    private static class ServiceInfoCompatHolder {
        private final AccessibilityServiceInfo info;
        ServiceInfoCompatHolder(AccessibilityServiceInfo info) { this.info = info; }
        boolean matches(String pkg, String cls) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) return false;
            return pkg.equals(info.getResolveInfo().serviceInfo.packageName)
                    && cls.equals(info.getResolveInfo().serviceInfo.name);
        }
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
